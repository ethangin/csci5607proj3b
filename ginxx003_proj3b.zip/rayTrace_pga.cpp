//CSCI 5607 HW3 - Rays & Files
//This HW has three steps:
// 1. Compile and run the program (the program takes a single command line argument)
// 2. Understand the code in this file (rayTrace_pga.cpp), in particular be sure to understand:
//     -How ray-sphere intersection works
//     -How the rays are being generated
//     -The pipeline from rays, to intersection, to pixel color
//    After you finish this step, and understand the math, take the HW quiz on canvas
// 3. Update the file parse_pga.h so that the function parseSceneFile() reads the passed in file
//     and sets the relevant global variables for the rest of the code to product to correct image

//To Compile: g++ -fsanitize=address -std=c++11 rayTrace_pga.cpp

//For Visual Studios
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

//Images Lib includes:
#define STB_IMAGE_IMPLEMENTATION //only place once in one .cpp file
#define STB_IMAGE_WRITE_IMPLEMENTATION //only place once in one .cpp files
#include "image_lib.h" //Defines an image class and a color class

//#3D PGA
#include "PGA_3D.h"

//High resolution timer
#include <chrono>

#include <algorithm>

//Scene file parser
#include "parse_pga.h"

#ifndef M_PI
    #define M_PI 3.14159265358979323846
#endif

struct Hit_info {
  Point3D hit_pt;
  Dir3D hit_normal;
  int sphere_id = -1;
  int tri_id = -1;
  float ior;
};

Color applyLighting(Dir3D ray, Point3D rayStart, Hit_info hit, int depth);
Color evaluateRay(Dir3D ray, Point3D rayStart, int depth);

bool raySphereIntersect_fast(Point3D rayStart, Line3D rayLine, Point3D sphereCenter, float sphereRadius){
  Dir3D dir = rayLine.dir();
  float a = dot(dir,dir);
  Dir3D toStart = (rayStart - sphereCenter);
  float b = 2 * dot(dir,toStart);
  float c = dot(toStart,toStart) - sphereRadius*sphereRadius;
  float discr = b*b - 4*a*c;
  if (discr < 0) return false;
  else{
    float t0 = (-b + sqrt(discr))/(2*a);
    float t1 = (-b - sqrt(discr))/(2*a);
    if (t0 > 0 || t1 > 0) return true;
  }
  return false;
}

Point3D raySphereIntersect(Point3D rayStart, Line3D rayLine, Point3D sphereCenter, float sphereRadius){
  Point3D projPoint = dot(rayLine,sphereCenter)*rayLine;      //Project to find closest point between circle center and line [proj(sphereCenter,rayLine);]
  float distSqr = projPoint.distToSqr(sphereCenter);          //Point-line distance (squared)
  float d2 = distSqr/(sphereRadius*sphereRadius);             //If distance is larger than radius, then...
  if (d2 > 1) return false;                                   //... the ray missed the sphere
  float w = sphereRadius*sqrt(1-d2);                          //Pythagorean theorem to determine dist between proj point and intersection points
  Point3D p1 = projPoint - rayLine.dir()*w;                   //Add/subtract above distance to find hit points
  Point3D p2 = projPoint + rayLine.dir()*w; 

  // if (dot((p1-rayStart),rayLine.dir()) >= 0) return (p1-rayStart).magnitude();     //Is the first point in same direction as the ray line?
  // if (dot((p2-rayStart),rayLine.dir()) >= 0) return (p2-rayStart).magnitude();     //Is the second point in same direction as the ray line?
  // return -1;
  if (dot((p1-rayStart),rayLine.dir()) >= 0 && p1.distToSqr(rayStart) > 0.0001) return p1;
  if (dot((p2-rayStart),rayLine.dir()) >= 0 && p2.distToSqr(rayStart) > 0.0001) return p2; 
  return Point3D(0,0,0); // no intersect
}

Point3D rayTriangleIntersect(Dir3D ray, Point3D rayStart, int t) {
  Plane3D plane = vee(vertices[triangle_vertices[3*t]], vertices[triangle_vertices[3*t+1]], vertices[triangle_vertices[3*t+2]]);
  HomogeneousPoint3D p = wedge(vee(rayStart, ray), plane);
  if (p.w == 0) {
    return Point3D(0,0,0);
  } else {
    return Point3D(wedge(vee(rayStart, ray), plane));
  }
}

float clamp(float val, float low, float high) {
  if (val < low) return low;
  if (val > high) return high;
  return val;
}

Color applyLighting(Dir3D ray, Point3D rayStart, Hit_info hit, int depth) {
  float r = 0, g = 0, b = 0;
  bool shadow = false;
  
  /*** SPHERE LIGHTING ***/
  if (hit.sphere_id != -1) {
    for (int l = 0; l < num_lights; l++) {
      shadow = false;  
      for (int s = 0; s < num_spheres; s++) {
        Line3D pt_to_light;
        if (light_type_array[l] == 0) {
          pt_to_light = vee(hit.hit_pt, -1 * light_dir_array[l]);
        } else {
          pt_to_light = vee(hit.hit_pt, light_location_array[l] - hit.hit_pt);
        }

        Point3D intersect = raySphereIntersect(hit.hit_pt + 0.01 * hit.hit_normal, pt_to_light, sphere_array[s], radius_array[s]);
        if (raySphereIntersect_fast(hit.hit_pt + 0.01 * hit.hit_normal, pt_to_light, sphere_array[s], 0.99*radius_array[s]) && intersect.distToSqr(hit.hit_pt) > 0.000001) {
          shadow = true;
          break;
        }
      }    

      if (!shadow) {
        Dir3D to_light, to_eye, bisect;
        float n_dot_l, n_dot_h;
        if (light_type_array[l] == 0) { // Directional Light
          // diffuse lighting
          Dir3D dir_light = light_dir_array[l];
          to_light = Dir3D(-dir_light.x, -dir_light.y, -dir_light.z);
          n_dot_l = dot(to_light.normalized(), hit.hit_normal);
          if (n_dot_l > 0) {
            r += dif_color_array[hit.sphere_id].r * intensity_array[l].r * n_dot_l;
            g += dif_color_array[hit.sphere_id].g * intensity_array[l].g * n_dot_l;
            b += dif_color_array[hit.sphere_id].b * intensity_array[l].b * n_dot_l;
          }

          // Phong specularity
          to_eye = eye - hit.hit_pt;
          bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
          n_dot_h = dot(hit.hit_normal, bisect);
          if (n_dot_h > 0) {
            r += spc_color_array[hit.sphere_id].r * intensity_array[l].r * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
            g += spc_color_array[hit.sphere_id].g * intensity_array[l].g * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
            b += spc_color_array[hit.sphere_id].b * intensity_array[l].b * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
          }
        } else if (light_type_array[l] == 1) { // Point Light
          // diffuse lighting
          to_light = (light_location_array[l] - hit.hit_pt);
          n_dot_l = dot(to_light.normalized(), hit.hit_normal);
          if (n_dot_l > 0) {
            r += dif_color_array[hit.sphere_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * n_dot_l;
            g += dif_color_array[hit.sphere_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * n_dot_l;
            b += dif_color_array[hit.sphere_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * n_dot_l;
          }

          // Phong specularity
          to_eye = eye - hit.hit_pt;
          bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
          n_dot_h = dot(hit.hit_normal, bisect);
          if (n_dot_h > 0) {
            r += spc_color_array[hit.sphere_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
            g += spc_color_array[hit.sphere_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
            b += spc_color_array[hit.sphere_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
          }
        } else if (light_type_array[l] == 2) { // Spot Light
          // diffuse lighting
          to_light = (light_location_array[l] - hit.hit_pt);
          float angle = acos(dot(-1 * to_light, light_dir_array[l]));
          float factor = 1;
          if (angle <= angle_array[2 * l]) {
            factor = 1;
          } else if (angle > angle_array[2 * l] && angle <= angle_array[2 * l + 1]) {
            float range = angle_array[2 * l + 1] - angle_array[2 * l];
            factor = (angle - angle_array[2 * l]) / range;
          } else {
            factor = 0;
          }
          n_dot_l = dot(to_light.normalized(), hit.hit_normal);
          if (n_dot_l > 0) {
            r += factor * dif_color_array[hit.sphere_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * n_dot_l;
            g += factor * dif_color_array[hit.sphere_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * n_dot_l;
            b += factor * dif_color_array[hit.sphere_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * n_dot_l;
          }

          // Phong specularity
          to_eye = eye - hit.hit_pt;
          bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
          n_dot_h = dot(hit.hit_normal, bisect);
          if (n_dot_h > 0) {
            r += factor * spc_color_array[hit.sphere_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
            g += factor * spc_color_array[hit.sphere_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
            b += factor * spc_color_array[hit.sphere_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit.sphere_id]);
          }
        } else {
          printf("Error: light type %d not recognized", light_type_array[l]);
        }
      }
    }

    
    Dir3D reflect = ray - 2 * dot(ray, hit.hit_normal) * hit.hit_normal;
    Color reflect_color = evaluateRay(reflect, hit.hit_pt, depth+1);
    r += spc_color_array[hit.sphere_id].r * reflect_color.r;
    g += spc_color_array[hit.sphere_id].g * reflect_color.g;
    b += spc_color_array[hit.sphere_id].b * reflect_color.b;

    
    float ior1 = 1.0 / hit.ior;
    float theta1 = acos(dot((-1 * ray), hit.hit_normal));
    float theta2 = asin(ior1 * sin(theta1));
    Dir3D refract1 = (ior1 * cos(theta1) - cos(theta2)) * hit.hit_normal - ior1 * (-1*ray);
    Point3D new_hit = raySphereIntersect(hit.hit_pt - 0.01 * hit.hit_normal, vee(hit.hit_pt, refract1).normalized(), sphere_array[hit.sphere_id], radius_array[hit.sphere_id]);
    Dir3D new_normal = (new_hit - sphere_array[hit.sphere_id]).normalized();
    float theta3 = acos(dot(refract1.normalized(), new_normal));
    float theta4 = asin(hit.ior * sin(theta3));
    Dir3D refract2 = (hit.ior * cos(theta3) - cos(theta4)) * (-1 * new_normal) - hit.ior * (-1*refract1);
    Color refract_color = evaluateRay(refract2.normalized() + 0.01 * new_normal, new_hit, depth+1);

    r += trn_color_array[hit.sphere_id].r * refract_color.r;
    g += trn_color_array[hit.sphere_id].g * refract_color.g;
    b += trn_color_array[hit.sphere_id].b * refract_color.b;
    

    r += amb_r*amb_color_array[hit.sphere_id].r;
    g += amb_g*amb_color_array[hit.sphere_id].g;
    b += amb_b*amb_color_array[hit.sphere_id].b;

    r = clamp(r,0,1);
    g = clamp(g,0,1);
    b = clamp(b,0,1);
  } 
  
  /*** TRIANGLE LIGHTING ***/
  else if (hit.tri_id != -1) {
    
    
    if (dot(ray, hit.hit_normal) > 0) {
      hit.hit_normal = -1 * hit.hit_normal;
    }
    for (int l = 0; l < num_lights; l++) {
      shadow = false;  
      for (int t = 0; t < num_triangles; t++) {
        Dir3D to_light;
        if (light_type_array[l] == 0) {
          to_light = -1 * light_dir_array[l];
        } else {
          to_light = light_location_array[l] - hit.hit_pt;
        }
        Point3D pt = rayTriangleIntersect(to_light, hit.hit_pt + 0.01*hit.hit_normal, t);
        if ( (pt - Point3D(0,0,0)).magnitude() != 0) {
          shadow = true;
          break;
        }
      }  

      if (!shadow) {
        Dir3D to_light, to_eye, bisect;
        float n_dot_l, n_dot_h;
        if (light_type_array[l] == 0) { // Directional Light
          // diffuse lighting
          Dir3D dir_light = light_dir_array[l];
          to_light = Dir3D(-dir_light.x, -dir_light.y, -dir_light.z);
          n_dot_l = dot(to_light.normalized(), hit.hit_normal);
          if (n_dot_l > 0) {
            r += t_dif_color_array[hit.tri_id].r * intensity_array[l].r * n_dot_l;
            g += t_dif_color_array[hit.tri_id].g * intensity_array[l].g * n_dot_l;
            b += t_dif_color_array[hit.tri_id].b * intensity_array[l].b * n_dot_l;
          }

          // Phong specularity
          to_eye = eye - hit.hit_pt;
          bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
          n_dot_h = dot(hit.hit_normal, bisect);
          if (n_dot_h > 0) {
            r += t_spc_color_array[hit.tri_id].r * intensity_array[l].r * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
            g += t_spc_color_array[hit.tri_id].g * intensity_array[l].g * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
            b += t_spc_color_array[hit.tri_id].b * intensity_array[l].b * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
          }
        } 
        
        else if (light_type_array[l] == 1) { // Point Light
          // diffuse lighting
          to_light = (light_location_array[l] - hit.hit_pt);
          n_dot_l = dot(to_light.normalized(), hit.hit_normal);
          if (n_dot_l > 0) {
            r += t_dif_color_array[hit.tri_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * n_dot_l;
            g += t_dif_color_array[hit.tri_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * n_dot_l;
            b += t_dif_color_array[hit.tri_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * n_dot_l;
          }

          // Phong specularity
          to_eye = eye - hit.hit_pt;
          bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
          n_dot_h = dot(hit.hit_normal, bisect);
          if (n_dot_h > 0) {
            r += t_spc_color_array[hit.tri_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
            g += t_spc_color_array[hit.tri_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
            b += t_spc_color_array[hit.tri_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
          }
        } 
        
        else if (light_type_array[l] == 2) { // Spot Light
          // // diffuse lighting
          // to_light = (light_location_array[l] - hit.hit_pt);
          // float angle = acos(dot(-1 * to_light, light_dir_array[l]));
          // float factor = 1;
          // if (angle <= angle_array[2 * l]) {
          //   factor = 1;
          // } else if (angle > angle_array[2 * l] && angle <= angle_array[2 * l + 1]) {
          //   float range = angle_array[2 * l + 1] - angle_array[2 * l];
          //   factor = (angle - angle_array[2 * l]) / range;
          // } else {
          //   factor = 0;
          // }
          // n_dot_l = dot(to_light.normalized(), hit.hit_normal);
          // if (n_dot_l > 0) {
          //   r += factor * t_dif_color_array[hit.tri_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * n_dot_l;
          //   g += factor * t_dif_color_array[hit.tri_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * n_dot_l;
          //   b += factor * t_dif_color_array[hit.tri_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * n_dot_l;
          // }

          // // Phong specularity
          // to_eye = eye - hit.hit_pt;
          // bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
          // n_dot_h = dot(hit.hit_normal, bisect);
          // if (n_dot_h > 0) {
          //   r += factor * t_spc_color_array[hit.tri_id].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
          //   g += factor * t_spc_color_array[hit.tri_id].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
          //   b += factor * t_spc_color_array[hit.tri_id].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, t_spc_highlight_array[hit.tri_id]);
          }
         
        
        else {
          printf("Error: light type %d not recognized", light_type_array[l]);
        }
      }
    }

    Dir3D reflect = ray - 2 * dot(ray, hit.hit_normal) * hit.hit_normal;
    Color reflect_color = evaluateRay(reflect, hit.hit_pt, depth+1);
    r += t_spc_color_array[hit.tri_id].r * reflect_color.r;
    g += t_spc_color_array[hit.tri_id].g * reflect_color.g;
    b += t_spc_color_array[hit.tri_id].b * reflect_color.b;

    
    float ior1 = 1.0 / hit.ior;
    float theta1 = acos(dot((-1 * ray), hit.hit_normal));
    float theta2 = asin(ior1 * sin(theta1));
    Dir3D refract1 = (ior1 * cos(theta1) - cos(theta2)) * hit.hit_normal - ior1 * (-1*ray);
    Point3D new_hit = raySphereIntersect(hit.hit_pt - 0.01 * hit.hit_normal, vee(hit.hit_pt, refract1).normalized(), sphere_array[hit.tri_id], radius_array[hit.tri_id]);
    Dir3D new_normal = (new_hit - sphere_array[hit.sphere_id]).normalized();
    float theta3 = acos(dot(refract1.normalized(), new_normal));
    float theta4 = asin(hit.ior * sin(theta3));
    Dir3D refract2 = (hit.ior * cos(theta3) - cos(theta4)) * (-1 * new_normal) - hit.ior * (-1*refract1);
    Color refract_color = evaluateRay(refract2.normalized() + 0.01 * new_normal, new_hit, depth+1);

    r += t_trn_color_array[hit.tri_id].r * refract_color.r;
    g += t_trn_color_array[hit.tri_id].g * refract_color.g;
    b += t_trn_color_array[hit.tri_id].b * refract_color.b;
    

    r += amb_r*t_amb_color_array[hit.tri_id].r;
    g += amb_g*t_amb_color_array[hit.tri_id].g;
    b += amb_b*t_amb_color_array[hit.tri_id].b;

    r = clamp(r,0,1);
    g = clamp(g,0,1);
    b = clamp(b,0,1);
  }

  return Color(r,g,b);
}

int findClosestSphere(Dir3D ray, Point3D rayStart) {
  int hit_sphere = -1;
  float closest_dist = 99999, cur_dist = -1;
  Point3D cur_pt;
  Dir3D normal;
  
  for (int s = 0; s < num_spheres; s++) {
    cur_pt = raySphereIntersect(rayStart, vee(rayStart, ray).normalized(), sphere_array[s],radius_array[s]);
    
    if ( (cur_pt - Point3D(0,0,0)).magnitude() != 0) {
      cur_dist = (cur_pt - rayStart).magnitude();
      if (cur_dist > 0 && cur_dist < closest_dist) {
        closest_dist = cur_dist;
        hit_sphere = s;
      }
    }        
  }

  return hit_sphere;
}

int findClosestTriangle(Dir3D ray, Point3D rayStart) {
  int hit_triangle = -1;
  float closest_dist = 99999, cur_dist = -1;
  Point3D cur_pt;
  for (int t = 0; t < num_triangles; t++) {
    //cur_pt = rayTriangleIntersect(ray, rayStart, vertices[triangle_vertices[3*hit_triangle]], vertices[triangle_vertices[3*hit_triangle+1]], vertices[triangle_vertices[3*hit_triangle+2]]);
    cur_pt = rayTriangleIntersect(ray, rayStart, t);
    if ( (cur_pt-Point3D(0,0,0)).magnitude() != 0.0) {
      Dir3D d = cur_pt - rayStart;
      if ( d.magnitude() < closest_dist && dot(d, ray) > 0) {
        closest_dist = d.magnitude();
        hit_triangle = t;
      }
    }
  }
  
  return hit_triangle;
}

Color evaluateRay(Dir3D ray, Point3D rayStart, int depth) {
  if (depth < max_depth) {
    int hit_sphere = findClosestSphere(ray, rayStart);
    int hit_triangle = findClosestTriangle(ray, rayStart);
    //printf("sphere %d triangle %d\n", hit_sphere, hit_triangle);
    if (hit_sphere == -1 && hit_triangle == -1) {
      return Color(back_r, back_g, back_b);
    } else {
      if (hit_sphere == -1) {
        Hit_info h;
        //Point3D intersect = rayTriangleIntersect(ray, rayStart, vertices[triangle_vertices[3*hit_triangle]], vertices[triangle_vertices[3*hit_triangle+1]], vertices[triangle_vertices[3*hit_triangle+2]]);
        Point3D intersect = rayTriangleIntersect(ray, rayStart, hit_triangle);
        h.hit_pt = intersect;
        // TODO: find triangle normal
        // float a = (intersect - vertices[triangle_vertices[3*hit_triangle]]).magnitude();
        // float b = (intersect - vertices[triangle_vertices[3*hit_triangle+1]]).magnitude();
        // float c = (intersect - vertices[triangle_vertices[3*hit_triangle+2]]).magnitude();
        // float total_dist = a+b+c;
        // float a_ratio = a/total_dist;
        // float b_ratio = b/total_dist;
        // float c_ratio = c/total_dist;
        // Dir3D normal = a_ratio * triangle_normals[3*hit_triangle] + a_ratio * triangle_normals[3*hit_triangle] + b_ratio * triangle_normals[3*hit_triangle] + c_ratio * triangle_normals[3*hit_triangle];
        Dir3D normal = triangle_normals[3 * hit_triangle];
        h.hit_normal = normal;
        h.tri_id = hit_triangle;
        h.sphere_id = -1;
        h.ior = ior_array[hit_triangle];
        return applyLighting(ray, rayStart, h, depth);
      } else if (hit_triangle == -1) {
        Hit_info h;
        Point3D intersect = raySphereIntersect(rayStart, vee(rayStart, ray), sphere_array[hit_sphere], radius_array[hit_sphere]);
        h.hit_pt = intersect;
        h.hit_normal = (intersect - sphere_array[hit_sphere]).normalized();
        h.sphere_id = hit_sphere;
        h.tri_id = -1;
        h.ior = ior_array[hit_sphere];
        return applyLighting(ray, rayStart, h, depth);
      } else {
        //Point3D intersect1 = rayTriangleIntersect(ray, rayStart, vertices[triangle_vertices[3*hit_triangle]], vertices[triangle_vertices[3*hit_triangle+1]], vertices[triangle_vertices[3*hit_triangle+2]]);
        Point3D intersect1 = rayTriangleIntersect(ray, rayStart, hit_triangle);
        Point3D intersect2 = raySphereIntersect(rayStart, vee(rayStart, ray), sphere_array[hit_sphere], radius_array[hit_sphere]);
        float dist1 = (intersect1 - rayStart).magnitude();
        float dist2 = (intersect2 - rayStart).magnitude();

        if (dist1 < dist2) {
          Hit_info h;
          h.hit_pt = intersect1;
          // TODO: find triangle normal
          // float a = (intersect - vertices[triangle_vertices[3*hit_triangle]]).magnitude();
          // float b = (intersect - vertices[triangle_vertices[3*hit_triangle+1]]).magnitude();
          // float c = (intersect - vertices[triangle_vertices[3*hit_triangle+2]]).magnitude();
          // float total_dist = a+b+c;
          // float a_ratio = a/total_dist;
          // float b_ratio = b/total_dist;
          // float c_ratio = c/total_dist;
          // Dir3D normal = a_ratio * triangle_normals[3*hit_triangle] + a_ratio * triangle_normals[3*hit_triangle] + b_ratio * triangle_normals[3*hit_triangle] + c_ratio * triangle_normals[3*hit_triangle];
          Dir3D normal = triangle_normals[3 * hit_triangle];
          h.hit_normal = normal;
          h.tri_id = hit_triangle;
          h.sphere_id = -1;
          h.ior = ior_array[hit_triangle];
          return applyLighting(ray, rayStart, h, depth);
        } else {
          Hit_info h;
          h.hit_pt = intersect2;
          h.hit_normal = (intersect2 - sphere_array[hit_sphere]).normalized();
          h.sphere_id = hit_sphere;
          h.tri_id = -1;
          h.ior = ior_array[hit_sphere];
          return applyLighting(ray, rayStart, h, depth);
        }
      }
    }
  } else {
    return Color(back_r, back_g, back_b);
  }
}

int main(int argc, char** argv){
  
  //Read command line paramaters to get scene file
  if (argc != 2){
     std::cout << "Usage: ./a.out scenefile\n";
     return(0);
  }
  std::string secenFileName = argv[1];

  //Parse Scene File
  parseSceneFile(secenFileName);

  float imgW = img_width, imgH = img_height;
  float halfW = imgW/2, halfH = imgH/2;
  float d = halfH / tanf(halfAngleVFOV * (M_PI / 180.0f));
  float r,g,b;

  Image outputImg = Image(img_width,img_height);
  auto t_start = std::chrono::high_resolution_clock::now();

  #pragma omp parallel for
  for (int i = 0; i < img_width; i++){
    for (int j = 0; j < img_height; j++){
      
      float u = (halfW - (imgW)*((i+0.5)/imgW));
      float v = (halfH - (imgH)*((j+0.5)/imgH));
      Point3D p = eye - d*forward + u*right + v*up;
      Dir3D rayDir = (p - eye); 
      Line3D rayLine = vee(eye,rayDir).normalized();  //Normalizing here is optional
      
      outputImg.setPixel(i,j, evaluateRay(rayDir.normalized(), eye, 0));
    }
  }
  auto t_end = std::chrono::high_resolution_clock::now();
  printf("Rendering took %.2f ms\n",std::chrono::duration<double, std::milli>(t_end-t_start).count());

  outputImg.write(imgName.c_str());

  //rayTriangleIntersect(up.normalized(), eye, Point3D(0,0,0), Point3D(0,1,0), Point3D(0,0,1));

  delete [] vertices;
  delete [] normals;
  delete [] triangle_vertices;
  delete [] triangle_normals;
  return 0;
}








/*
      bool hit = false;
      int hit_sphere = -1;
      float closest_dist = 99999, cur_dist = -1, n_dot_l, n_dot_h;
      Point3D cur_pt, closest_pt(999,999,999);
      Dir3D normal, to_light, to_eye, bisect;
      r=g=b=0;
      
      for (int s = 0; s < num_spheres; s++) {
        cur_pt = raySphereIntersect(eye,rayLine,sphere_array[s],radius_array[s]);
        
        if ( (cur_pt - Point3D(0,0,0)).magnitude() != 0) {
          cur_dist = (cur_pt - eye).magnitude();
          if (cur_dist > 0 && cur_dist < closest_dist) {
            hit = true;
            closest_dist = cur_dist;
            closest_pt = cur_pt;
            hit_sphere = s;
          }
        }        
      }

      Color color;
      bool shadow = false;
      if (hit) {
        normal = (closest_pt - sphere_array[hit_sphere]).normalized();
        
        for (int l = 0; l < num_lights; l++) {
          shadow = false;
          
          for (int s = 0; s < num_spheres; s++) {
            Line3D pt_to_light;
            if (light_type_array[l] == 0) {

            } else {
              pt_to_light = vee(closest_pt, light_location_array[l] - closest_pt);
            }

            Point3D intersect = raySphereIntersect(closest_pt, pt_to_light, sphere_array[s], radius_array[s]);
            if (raySphereIntersect_fast(closest_pt, pt_to_light, sphere_array[s], 0.99*radius_array[s]) && intersect.distToSqr(closest_pt) > 0.000001) {
              shadow = true;
              break;
            }
          }
          
          if (!shadow) {
            if (light_type_array[l] == 0) { // Directional Light
              // diffuse lighting
              Dir3D dir_light = light_dir_array[l];
              to_light = Dir3D(-dir_light.x, -dir_light.y, -dir_light.z);
              n_dot_l = dot(to_light.normalized(), normal);
              if (n_dot_l > 0) {
                r += dif_color_array[hit_sphere].r * intensity_array[l].r * n_dot_l;
                g += dif_color_array[hit_sphere].g * intensity_array[l].g * n_dot_l;
                b += dif_color_array[hit_sphere].b * intensity_array[l].b * n_dot_l;
              }

              // Phong specularity
              to_eye = eye - closest_pt;
              bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
              n_dot_h = dot(normal, bisect);
              if (n_dot_h > 0) {
                r += spc_color_array[hit_sphere].r * intensity_array[l].r * pow(n_dot_h, spc_highlight_array[hit_sphere]);
                g += spc_color_array[hit_sphere].g * intensity_array[l].g * pow(n_dot_h, spc_highlight_array[hit_sphere]);
                b += spc_color_array[hit_sphere].b * intensity_array[l].b * pow(n_dot_h, spc_highlight_array[hit_sphere]);
              }
            } else if (light_type_array[l] == 1) { // Point Light
              // diffuse lighting
              to_light = (light_location_array[l] - closest_pt);
              n_dot_l = dot(to_light.normalized(), normal);
              if (n_dot_l > 0) {
                r += dif_color_array[hit_sphere].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * n_dot_l;
                g += dif_color_array[hit_sphere].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * n_dot_l;
                b += dif_color_array[hit_sphere].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * n_dot_l;
              }

              // Phong specularity
              to_eye = eye - closest_pt;
              bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
              n_dot_h = dot(normal, bisect);
              if (n_dot_h > 0) {
                r += spc_color_array[hit_sphere].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit_sphere]);
                g += spc_color_array[hit_sphere].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit_sphere]);
                b += spc_color_array[hit_sphere].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit_sphere]);
              }
            } else if (light_type_array[l] == 2) { // Spot Light
              // diffuse lighting
              to_light = (light_location_array[l] - closest_pt);
              float angle = acos(dot(-1 * to_light, light_dir_array[l]));
              float factor = 1;
              if (angle <= angle_array[2 * l]) {
                factor = 1;
              } else if (angle > angle_array[2 * l] && angle <= angle_array[2 * l + 1]) {
                float range = angle_array[2 * l + 1] - angle_array[2 * l];
                factor = (angle - angle_array[2 * l]) / range;
              } else {
                factor = 0;
              }
              n_dot_l = dot(to_light.normalized(), normal);
              if (n_dot_l > 0) {
                r += factor * dif_color_array[hit_sphere].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * n_dot_l;
                g += factor * dif_color_array[hit_sphere].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * n_dot_l;
                b += factor * dif_color_array[hit_sphere].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * n_dot_l;
              }

              // Phong specularity
              to_eye = eye - closest_pt;
              bisect = (to_eye + to_light) / (to_eye + to_light).magnitude();
              n_dot_h = dot(normal, bisect);
              if (n_dot_h > 0) {
                r += factor * spc_color_array[hit_sphere].r * intensity_array[l].r / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit_sphere]);
                g += factor * spc_color_array[hit_sphere].g * intensity_array[l].g / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit_sphere]);
                b += factor * spc_color_array[hit_sphere].b * intensity_array[l].b / pow(to_light.magnitude(), 2.0) * pow(n_dot_h, spc_highlight_array[hit_sphere]);
              }
            } else {
              printf("Error: light type %d not recognized", light_type_array[l]);
            }
          }
        }

        // ambient light
        r += amb_r*amb_color_array[hit_sphere].r;
        g += amb_g*amb_color_array[hit_sphere].g;
        b += amb_b*amb_color_array[hit_sphere].b;
        
        color = Color(r,g,b);        
      }
      else {
        color = Color(back_r,back_g,back_b);
      }
      
      outputImg.setPixel(i,j, color);
      //outputImg.setPixel(i,j, Color(fabs(i/imgW),fabs(j/imgH),fabs(0))); //TODO: Try this, what is it visualizing?
      */